

<?php $__env->startSection('container'); ?>
    <h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\applications\coba2-laravel\resources\views/home.blade.php ENDPATH**/ ?>