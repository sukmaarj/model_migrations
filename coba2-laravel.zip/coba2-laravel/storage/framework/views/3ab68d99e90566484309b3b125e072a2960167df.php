

<?php $__env->startSection('container'); ?>
    <h2>Halaman About</h2>
    <h3><?php echo e($name); ?></h3>
    <p><?php echo e($email); ?></p>
    <img src="img/<?php echo e($image); ?>" alt=" $  }}" width="200" >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\applications\coba2-laravel\resources\views/about.blade.php ENDPATH**/ ?>