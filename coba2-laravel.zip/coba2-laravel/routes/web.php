<?php

use App\Models\Post;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;

Route::get('/', function () {
    return view('home', [
        "title" => "Home"
    ]);
});

Route::get('/about', function () {
    return view('about', [
        'title' => 'About',
        "name" => "Sukma Arjanah",
        "email" => "sukmaarjanah9@gmail.com",
        "image" => "profil.jpg"
    ]);
});



Route::get('/blog', function () {
    $blog_posts = [
        [
            "title" => "Judul Post Pertama",
            "author" => "Sukma Arjanah",
            "body" => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Mollitia ad consequatur delectus, eos qui voluptates repellendus atque culpa, aspernatur et reiciendis eius perspiciatis veritatis voluptate. Blanditiis cumque sit perferendis unde dolor repellat dignissimos esse eum aut dicta! Alias nihil quisquam et sit distinctio eum consequuntur eligendi odio. Velit est perferendis adipisci molestiae alias a illum odio earum, laborum obcaecati eaque eius at in. Sit dolorum distinctio, suscipit voluptas consequuntur cum incidunt quisquam alias molestias voluptate ex modi in? Asperiores, similique."
        ],
        [
            "title" => "Judul Post Pertama",
            "author" => "Sukmaarj",
            "body" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aspernatur qui quas pariatur. Accusantium fuga ex illum impedit tenetur excepturi culpa est necessitatibus praesentium aliquam atque vero explicabo reiciendis dignissimos ipsa quia beatae quibusdam non dolores numquam modi, aliquid architecto soluta pariatur! Esse aliquid maxime laborum aperiam nisi numquam sit temporibus dicta explicabo animi dignissimos, dolorem ex voluptatum perferendis eveniet quo sunt tempore excepturi officiis. Autem provident magnam perspiciatis eligendi fuga repudiandae dolor asperiores quas et. Veritatis aliquam hic quae nobis quia alias quaerat sit tenetur eveniet. Quos veritatis incidunt dolore molestias quibusdam optio laborum repellat ipsa, necessitatibus consequuntur earum eos?"
        ],
    ];
    return view('posts', [
        "title" => "Posts",
        "posts" => $blog_posts
    ]);
});